# MirrorTone GPT-5x Repro Suite

This repo runs a small reproducible evaluation suite on two models and generates a markdown delta table.

## How to run
1) Add GitHub Secret: OPENAI_API_KEY
2) Go to Actions → "Eval GPT-5x Repro Suite" → Run workflow
3) After it finishes, open docs/delta_table.md
